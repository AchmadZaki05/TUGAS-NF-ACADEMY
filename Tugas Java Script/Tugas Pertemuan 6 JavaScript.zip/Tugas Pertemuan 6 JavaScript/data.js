// data.js
const data = [
    { nama: "Robert Sánchez", umur: 27, alamat: "Goalkeeper", email: "sanchez@chelsea.com" },
    { nama: "Ben Chilwell", umur: 28, alamat: "Defender", email: "chilwell@chelsea.com" },
    { nama: "Axel Disasi", umur: 27, alamat: "Defender", email: "disasi@chelsea.com" },
    { nama: "Levi Colwill", umur: 22, alamat: "Defender", email: "colwill@chelsea.com" },
    { nama: "Trevoh Chalobah", umur: 26, alamat: "Defender", email: "chalobah@chelsea.com" },
    { nama: "Moisés Caicedo", umur: 23, alamat: "Midfielder", email: "caicedo@chelsea.com" },
    { nama: "Enzo Fernández", umur: 24, alamat: "Midfielder", email: "enzo@chelsea.com" },
    { nama: "Conor Gallagher", umur: 25, alamat: "Midfielder", email: "gallagher@chelsea.com" },
    { nama: "Cole Palmer", umur: 23, alamat: "Forward", email: "palmer@chelsea.com" },
    { nama: "Raheem Sterling", umur: 30, alamat: "Forward", email: "sterling@chelsea.com" }
];

module.exports = data;
