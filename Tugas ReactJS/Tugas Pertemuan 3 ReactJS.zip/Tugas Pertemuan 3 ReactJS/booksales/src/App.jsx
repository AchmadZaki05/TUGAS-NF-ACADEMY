import Home from './Pages';
import Header from './tugas2rjs/shared/Header';
import Hero from './tugas2rjs/shared/Hero';


function App() {
  return (
    <>
 <Home/>
    </>
  )
}

export default App
