import Contact from "../../Pages/Contact";

export default function Kontak () {
return (
<>
<Contact/>
</>
)
}