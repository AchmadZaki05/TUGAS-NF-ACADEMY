import Team from "../../Pages/Team";

export default function Tim () {
return (
<>
<Team/>
</>
)
}